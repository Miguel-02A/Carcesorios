import { StyleSheet,Text,View,Button,Image } from 'react-native';

import { Card } from 'react-native-paper';


export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>
        Bienevenidos chicos <Text style={styles.tituloBold}>2558108</Text>
      </Text>

      <Button
        title="Clases"
        onPress={()=> {
          console.log('Presionaste el boton');
        }}></Button>

      <Text style={styles.titulo}>
        Contenedor <Text style={styles.tituloBold}>1</Text>
      </Text>

      
      <Text style={styles.titulo}>
        Contenedor <Text style={styles.tituloBold}>2</Text>
      </Text>

      <Text style={styles.titulo}>
        Contenedor <Text style={styles.tituloBold}>3</Text>
      </Text>

    </View>
    
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 4,
    backgroundColor: '#f3f4f6',
    padding: 8,
  },
  titulo:{
    margin: 24,
    fontSize: 30,
    textTransform: 'uppercase',
    fontWeight: 600,
    color: '#374151',
    textAlign: 'center',
  },
  tituloBold: {
    fontWeight: '900',
    color: '#6D28D9'
  },
});










